create database productManagementDB

use productManagementDB
drop table ProductList
create table ProductList
(
	pId int primary key identity,
	pName varchar(20),
	pCategory varchar(20),
	pPrice float,
	pIsAvailabe bit,
	pDiscountRate int,
	pMaker varchar(20)
)

insert into ProductList values('Pepsi','Cold-Drink',50,1,0,'Pepsi')
insert into ProductList values('Maggie','Fast-Food',65,1,10,'Nestle')
insert into ProductList values('Iphone','Phone',800,0,25,'Apple')
insert into ProductList values('Fossil','Watch',250,15,1,'Titan')
insert into ProductList values('Pasta','Fast-Food',60,1,0,'Nestle')

create table customers
(
	cId int primary key identity,
	cName varchar(20),
	cCity varchar(20),
	cWalletBalance int
	)

	insert into customers values('Rahul','Mumbai',9000)
	insert into customers values('Karan','Pune',12000)
	insert into customers values('Sahil','Mumbai',9000)
	insert into customers values('Rohan','Chennai',18000)


)


select * from ProductList

select * from customers