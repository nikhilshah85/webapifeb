﻿using System;
using System.Collections.Generic;

namespace productManagementEF.Models
{
    public partial class ProductList
    {
        public int PId { get; set; }
        public string PName { get; set; }
        public string PCategory { get; set; }
        public double? PPrice { get; set; }
        public bool? PIsAvailabe { get; set; }
        public int? PDiscountRate { get; set; }
        public string PMaker { get; set; }
    }
}
