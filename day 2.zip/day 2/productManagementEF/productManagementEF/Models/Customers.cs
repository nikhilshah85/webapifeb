﻿using System;
using System.Collections.Generic;

namespace productManagementEF.Models
{
    public partial class Customers
    {
        public int CId { get; set; }
        public string CName { get; set; }
        public string CCity { get; set; }
        public int? CWalletBalance { get; set; }
    }
}
