﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using productManagementEF.Models;

namespace productManagementEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        //this is we, developer, createing the object, we are responsible to destroy the same
        //if we want to share this object with multiple request, we will declare it as static for singleton
        //if we want to have the object available per session, we will create more objects and take take responsibility to destroy them
        //if we want to have this object per call
        //instead, we use dependency injection, an inbuilt feature of .net framework core, which will manage everything for us
        productManagementDBContext dbRef = new productManagementDBContext();

        [HttpGet]
        [Route("products")]
        public IActionResult ProductList()
        {
            return Ok(dbRef.ProductList.ToList());
        }

        [HttpGet]
        [Route("productbyid")]
        public IActionResult ProductById(int id)
        {
            var pr = (from p in dbRef.ProductList
                      where p.PId == id
                      select p).Single();

            return Ok(pr); //200 everything is ok and good
        }

        [HttpPost]
        [Route("add")]
        public IActionResult AddProduct(ProductList newProduct)
        {
            //so your validations
            if (newProduct.PName.Length < 3)
            {
                return StatusCode(StatusCodes.Status510NotExtended, "Please Provide a valid Name");
            }
            dbRef.ProductList.Add(newProduct);
            dbRef.SaveChanges();
            return Created("", "Product Added Successfully"); //new resource is been created
        }


        [HttpDelete]
        [Route("delete")]
        public IActionResult DeleteProduct(int id)
        {
            try
            {
                var pr = (from p in dbRef.ProductList
                          where p.PId == id
                          select p).Single();
                dbRef.ProductList.Remove(pr);
                dbRef.SaveChanges();
                return StatusCode(StatusCodes.Status410Gone,"Product deleted Successfully");
            }
            catch (Exception er)
            {
                return NotFound("Sorry, Product ID did not match");
            }

        }


        [HttpPut]
        [Route("update")]
        public IActionResult UpdateProduct(ProductList changes)
        {
            var pr = (from p in dbRef.ProductList
                      where p.PId == changes.PId
                      select p).Single();

            pr.PName = changes.PName;
            pr.PPrice = changes.PPrice;
            pr.PCategory = changes.PCategory;

            dbRef.SaveChanges();

            return Accepted("","Product updated successfully");

        }
    }
}
