﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Call_WebAPI.Models
{
    public class CommentsModel
    {
        public string PostId { get; set; }
        public string ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Body { get; set; }

        List<CommentsModel> commentList = new List<CommentsModel>();


        public List<CommentsModel> GetComments()
        {

            HttpClient client = new HttpClient();
            string url = "https://jsonplaceholder.typicode.com/comments";

            client.DefaultRequestHeaders.Accept.Clear(); //different browsers, make call in differnt formats
                                                         //eg. Chrom in XML, IE in JSON, Android in someformat

            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));


            var call = client.GetAsync(url);

            List<CommentsModel> resultData = new List<CommentsModel>();
            var response = call.Result;

            if (response.IsSuccessStatusCode)
            {
                var read = response.Content.ReadAsAsync<List<CommentsModel>>();
                read.Wait();
                resultData = read.Result;
            }

            return resultData;

        }
    }
}
