﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Call_WebAPI.Models;
namespace Call_WebAPI.Controllers
{
    public class apicall2Controller : Controller
    {

        CommentsModel obj = new CommentsModel();

        public IActionResult GetComments()
        {
            ViewBag.comments = obj.GetComments();
            return View();
        }
    }
}